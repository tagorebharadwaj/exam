#include <stdio.h>
#include <math.h>

void knapsackBruteForce(float p[], float w[], float capacity, int n) {
    int bestChoice[32] = {0};
    int currentChoice[32] = {0};
    float bestValue = 0.0;
    float bestWeight = 0.0;
    
    // Total combinations = 2^n
    int totalCombinations = pow(2, n);

    // Loop through all numbers from 1 to 2^n - 1
    for (int i = 1; i < totalCombinations; i++) {
        // Generate binary representation for combination i
        int j = n - 1;
        while (currentChoice[j] != 0 && j > 0) {
            currentChoice[j] = 0;
            j--;
        }
        currentChoice[j] = 1;

        // Calculate total weight and value for current combination
        float tempWeight = 0.0;
        float tempValue = 0.0;

        for (int k = 0; k < n; k++) {
            if (currentChoice[k] == 1) {
                tempWeight += w[k];
                tempValue += p[k];
            }
        }

        // Update optimal choice if within capacity and total value is greater
        if (tempWeight <= capacity && tempValue > bestValue) {
            bestValue = tempValue;
            bestWeight = tempWeight;
            for (int k = 0; k < n; k++) {
                bestChoice[k] = currentChoice[k];
            }
        }
    }

    // Output results
    printf("Optimal Solution:\n");
    printf("Selected Items (Vector): [ ");
    for (int k = 0; k < n; k++) {
        printf("%d ", bestChoice[k]);
    }
    printf("]\n");
    printf("Total Weight: %.2f\n", bestWeight);
    printf("Maximum Profit: %.2f\n", bestValue);
}

int main() {
    int n = 4;
    float profits[] = {40, 30, 20, 10};
    float weights[] = {2, 5, 10, 5};
    float capacity = 16;

    knapsackBruteForce(profits, weights, capacity, n);

    return 0;
}