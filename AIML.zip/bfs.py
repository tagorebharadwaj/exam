from collections import deque

def bfs(graph, start, goal): 
    visited = set() 
    queue = deque([start])  

    while queue: 
        node = queue.popleft()  

        if node == goal: 
            print("Goal found!") 
            return True 

        if node not in visited: 
            visited.add(node) 
            print("Visited node:", node) 
            queue.extend(graph[node])  

    print("Goal not found!") 
    return False 

# Define the graph
graph = { 
    'S': ['A','B', 'C'], 
    'A': ['D', 'E'], 
    'B': ['G'], 
    'C': ['F'], 
    'D': ['H'], 
    'E': ['G'], 
    'F': ['G'], 
    'H':[], 
    'G':[] 
} 

bfs(graph, 'S', 'G')