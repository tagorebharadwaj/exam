import numpy as np 
import matplotlib.pyplot as plt 
weeks =np.array([2,3,4,5,6,7,8,9,10]) 
sales =np.array([5,6,10,12,11,14,18,20,22]) 
weeks_mean=np.mean(weeks) 
sales_mean=np.mean(sales) 
num=np.sum((weeks - weeks_mean)*(sales - sales_mean)) 
den=np.sum((weeks - weeks_mean) ** 2) 
B1=num/den 
B0= sales_mean - B1 * weeks_mean 
sales_pred= B0+ B1 * 11 
plt.scatter(weeks,sales,label='Data') 
plt.plot(weeks,B0 +B1 * weeks,label='Best -fit line', color ='red') 
plt.xlabel('Weeks') 
plt.ylabel('Sales') 
plt.title('Sales vs Weeks') 
plt.legend() 
plt.show() 
mae = np.mean(np.abs(sales - sales_pred)) 
mse = np.mean((sales - sales_pred) ** 2) 
fmse = np.sqrt(mse) 
r2= 1-(mse / np.var(sales)) 
print(f"predicted sales for week 11,{ sales_pred}") 
print(f"Mean Absolute Error: {mae}") 
print(f"Mean Squarede Error: { mse}") 
print(f"Root Mean Squared Error :{fmse}") 
print(f"R-Squared :{r2}") 