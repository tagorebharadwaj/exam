import heapq 
def greedy_bfs(graph, start, goal, heuristic): 
    visited = set() 
    priority_queue = [(heuristic[start], start)] 
    heapq.heapify(priority_queue) 
    while priority_queue: 
        current_heuristic, current = heapq.heappop(priority_queue)
        if current == goal: 
            print("Goal found!") 
            return True 
        if current not in visited: 
            visited.add(current) 
            print("Visited node:", current) 
            for neighbor in graph[current]: 
                if neighbor not in visited: 
                    heapq.heappush(priority_queue,(heuristic[neighbor],neighbor)) 
    print("Goal not found!") 
    return False 
# Define the graph as an adjacency list 
graph = { 
    'S': ['A', 'B', 'C'], 
    'A': ['D','E','G'], 
    'B': ['G'], 
    'C': ['G'], 
    'D': [], 
    'E': [], 
    'G':[]  } 
'''Define the costs for each edge (though costs are not used in GBFS, they are part of the graph 
definition) 
costs = { 
    ('S', 'A'): 1, 
    ('S', 'B'): 5, 
    ('S', 'C'): 8, 
    ('A', 'D'): 3, 
    ('A', 'E'): 7, 
    ('A','G'):9, 
    ('B','G'):4, 
    ('C','G'):5 
}''' 
# Define the heuristic values for each node 
heuristic = { 
'S':8, 
'A': 8, 
'B': 4, 
'C': 3, 
'D': -1, 
'E': -1, 
'G': 0  # Goal node has a heuristic value of 0 
} 
# Call Greedy BFS to search for node 'G' starting from node 'A' 
greedy_bfs(graph, 'S', 'G', heuristic)