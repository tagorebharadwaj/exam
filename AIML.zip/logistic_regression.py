import pandas as pd 
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LogisticRegression 
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score,confusion_matrix 
data={ 
'Age':[22,25,47,52,46,56,55,60,62,61,18,17,19,20], 
'Salary':[15000,18000,50000,60000,52000,61000,58000,68000,70000,72000,10000,12000,11000,14000], 
'Bought':[0,0,1,1,1,1,1,1,1,1,0,0,0,0] 
} 
df=pd.DataFrame(data) 
x=df[['Age','Salary']] 
y=df['Bought'] 
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=42) 
model=LogisticRegression() 
model.fit(x_train,y_train) 
y_pred=model.predict(x_test) 
accuracy= accuracy_score(y_test,y_pred) 
precision=precision_score(y_test,y_pred) 
recall=recall_score(y_test,y_pred) 
f1=f1_score(y_test,y_pred) 
conf_matrix=confusion_matrix(y_test,y_pred) 
print(f'Accuracy: {accuracy}') 
print(f'Precision: {precision}') 
print(f'Recall:{recall}') 
print(f'F1 score:{f1}') 
print(f'Confusion Matric:\n{conf_matrix}') 
new_data=pd.DataFrame({'Age':[30],'Salary':[40000]}) 
prediction=model.predict(new_data) 
print(f'Prediction for new data (Age : 30, salary :40000):{"Brought" if prediction[0] == 1 else "Not Bought"}')