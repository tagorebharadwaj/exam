def dfs(graph, start, goal): 
    visited = set() 
    stack = [start]  
 
    while stack: 
        node = stack.pop()  
        if node == goal: 
            print("Goal found!") 
            return True 
        if node not in visited: 
            visited.add(node) 
            print("Visited node:", node) 
            stack.extend(reversed(graph[node]))  
 
    print("Goal not found!") 
    return False  
 
graph = { 
   'S': ['A','B', 'C'], 
    'A': ['D', 'E'], 
    'B': ['G'], 
    'C': ['F'], 
    'D': ['H'], 
    'E': ['G'], 
    'F': ['G'], 
     'H':[], 
    'G':[] 
} 
  
dfs(graph, 'S', 'G') 
