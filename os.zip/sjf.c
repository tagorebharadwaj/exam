#include <stdio.h>

int main()
{
    int n, p[10], bt[10], ct[10], tat[10], wt[10];
    int i, j, temp;
    float total_tat = 0, total_wt = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    // Input process IDs
    printf("\nEnter process IDs:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &p[i]);
    }

    // Input burst times
    printf("\nEnter burst times:\n");
    for(i = 0; i < n; i++)
    {
        printf("Burst time for P%d: ", p[i]);
        scanf("%d", &bt[i]);
    }

    // 🔹 Bubble Sort based on burst time (SJF logic)
    for(i = 0; i < n - 1; i++)
    {
        for(j = 0; j < n - i - 1; j++)
        {
            if(bt[j] > bt[j+1])
            {
                // swap burst time
                temp = bt[j];
                bt[j] = bt[j+1];
                bt[j+1] = temp;

                // swap process IDs
                temp = p[j];
                p[j] = p[j+1];
                p[j+1] = temp;
            }
        }
    }

    // 🔹 Calculate Completion Time (CT)
    ct[0] = bt[0];
    for(i = 1; i < n; i++)
    {
        ct[i] = ct[i-1] + bt[i];
    }

    // 🔹 Calculate TAT and WT
    for(i = 0; i < n; i++)
    {
        tat[i] = ct[i];              // since AT = 0
        wt[i] = tat[i] - bt[i];

        total_tat += tat[i];
        total_wt += wt[i];
    }

    // 🔹 Output
    printf("\nProcess\tBT\tCT\tTAT\tWT\n");
    for(i = 0; i < n; i++)
    {
        printf("P%d\t%d\t%d\t%d\t%d\n", p[i], bt[i], ct[i], tat[i], wt[i]);
    }

    printf("\nAverage Turnaround Time = %.2f", total_tat / n);
    printf("\nAverage Waiting Time = %.2f\n", total_wt / n);

    return 0;
}