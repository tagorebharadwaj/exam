#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
void* demo(void* args)
{
printf("Thread executed...Pid=%d\n",getpid());
printf("Thread ID=%ld\n",pthread_self());
}
void main()
{
pthread_t tid;
printf("Main starts...Pid=%d\n",getpid());
pthread_create(&tid,NULL,demo,NULL);
pthread_join(tid,NULL);
printf("Main ends\n");
}