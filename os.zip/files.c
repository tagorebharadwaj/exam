#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
void main()
{
char src[100],dest[100];
int fd1,fd2;
char b;
printf("Enter source file:");
scanf("%s",src);
printf("Enter destination file:");
scanf("%s",dest);
fd1=open(src,O_RDONLY,NULL);
fd2=open(dest,O_WRONLY | O_CREAT,0666);
while(read(fd1,&b,1))
{
write(fd2,&b,1);
}
printf("File copy completed\n");
}