#include<stdio.h>
void main()
{
    int n,at[10],bt[10],i,ct[10],tat[10],totaltat=0,wt[10],sum,totalwt=0;
    printf("Enter the number of process");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("Enter the arrivial time p%d",i+1);
        scanf("%d",&at[i]);
        printf("Enter the burst time p%d",i+1);
        scanf("%d",&bt[i]);
    }
    //calculate C T
    sum=at[0];
    for(i=0;i<n;i++)
    {
        sum=sum+bt[i];
        ct[i]=sum;
    }
    //calculate TAT
    for(i=0;i<n;i++)
    {
        tat[i]=ct[i]-at[i];
        totaltat=totaltat+tat[i];
    }
    //calculate WT
    for(i=0;i<n;i++)
    {
        wt[i]=tat[i]-bt[i];
        totalwt=totalwt+wt[i];
    }
    printf("\nprocess\tAT\tBT\tCT\tTAT\tWT\n");
    for(i=0;i<n ;i++)
    {
        printf("p%d\t%d\t%d\t%d\t%d\t%d\n",i+1,at[i],bt[i],ct[i],tat[i],wt[i]);
    }
    printf("avg TAT =%d",totaltat/n);
    printf("avg WT =%d",totalwt/n);
  }