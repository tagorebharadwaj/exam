#include<stdio.h>
#include<unistd.h>
void main()
{
printf("p1 starts\n");
execl("./p2","p2",NULL);
printf("p1 ends\n");
}