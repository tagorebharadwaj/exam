#include<stdio.h>
#include<unistd.h>
#include<wait.h>
void main()
{
pid_t p;
printf("main starts\n");
p=fork();
if(p==0)
{
printf("Child executed\n");
}
else if(p>0)
{
printf("Parent process running\n");
pause();
printf("Parent process completed\n");
}
printf("main ends\n");
}
