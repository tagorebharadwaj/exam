#include<stdio.h>
#include<unistd.h>
int main()
{
pid_t pid;
pid=fork();
if(pid>0)
{
printf("Parent Process Created.Its Id=%d\n",getpid());
}
else if(pid==0)
{
printf("Child Process Created.Its Id=%d\n",getpid());
}
else
printf("Error in process creation\n");
return 0;
}