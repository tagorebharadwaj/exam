#include <stdio.h>

int main()
{
    int n, bt[10], rt[10], tat[10], wt[10];
    int i, time = 0, tq, remain, total_tat = 0, total_wt = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    // Input burst time
    for(i = 0; i < n; i++)
    {
        printf("Enter burst time of P%d: ", i + 1);
        scanf("%d", &bt[i]);
        rt[i] = bt[i];   // remaining time
    }

    printf("Enter time quantum: ");
    scanf("%d", &tq);

    remain = n;

    // 🔹 Round Robin Logic
    while(remain > 0)
    {
        for(i = 0; i < n; i++)
        {
            if(rt[i] > 0)
            {
                if(rt[i] > tq)
                {
                    time += tq;
                    rt[i] -= tq;
                }
                else
                {
                    time += rt[i];
                    wt[i] = time - bt[i];
                    tat[i] = time;
                    rt[i] = 0;
                    remain--;
                }
            }
        }
    }

    // 🔹 Output
    printf("\nProcess\tBT\tTAT\tWT\n");
    for(i = 0; i < n; i++)
    {
        printf("P%d\t%d\t%d\t%d\n", i+1, bt[i], tat[i], wt[i]);
        total_tat += tat[i];
        total_wt += wt[i];
    }

    printf("\nAverage Turnaround Time = %.2f", (float)total_tat / n);
    printf("\nAverage Waiting Time = %.2f\n", (float)total_wt / n);

    return 0;
}