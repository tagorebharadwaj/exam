#include<stdio.h>
#include<unistd.h>
#include<wait.h>
int main()
{
pid_t pid;
pid=fork();
if(pid>0)
{
printf("Parent Process Started\n");
wait(NULL);
printf("Parent Process Completed\n");
}
else if(pid==0)
{
printf("Child Process Started\n");
sleep(5);
printf("Child Process Completed\n");
}
else
printf("Error in process creation\n");
return 0;
}