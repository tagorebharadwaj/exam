#include <stdio.h>
int main()
{
    int frm[30],ref[30],nof,nop,pf=0,flag=0,i,j,victim=-1;
    printf("Enter no. of frames:");
    scanf("%d",&nof);
    printf("Enter no. of pages:");
    scanf("%d",&nop);
    printf("Enter page reference string:");
    for(i=0;i<nop;i++)
        scanf("%d",&ref[i]);
    for(i=0;i<nof;i++)
        frm[i]=-1;
    printf("\n");
    for(i=0;i<nop;i++)
    {
        flag=0;
        printf("\n\tReference pn=%d\t",ref[i]);
        for(j=0;j<nof;j++)
        {
            if(frm[j]==ref[i])
            {
                flag=1;
                printf("Page Hit\n");
                break;
            }
        }
        if(flag==0)
        {
            pf++;
            victim++;
            victim=victim%nof;
            frm[victim]=ref[i];
            for(j=0;j<nof;j++)
                printf("%4d",frm[j]);
        }
    }
    printf("\n\nNo. of page faults=%d\n",pf);
    return 0;
}