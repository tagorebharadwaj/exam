#include <stdio.h>

int tq[20], nof;
int find();

int main()
{
    int count = 0, frm[10], nop, ref[20], i, j, flag, victim = -1, pf = 0;
    
    printf("Enter no. of pages,frames: ");
    scanf("%d%d", &nop, &nof);
    
    printf("Enter page reference string: ");
    for(i = 0; i < nop; i++)
        scanf("%d", &ref[i]);
        
    for(i = 0; i < nof; i++)
    {
        frm[i] = victim;
        tq[i] = 0;
    }
    
    for(i = 0; i < nop; i++)
    {
        count++;
        flag = 0;
        printf("\nReference string=%d\t", ref[i]);
        
        // Check for page hit
        for(j = 0; j < nof; j++)
        {
            if(frm[j] == ref[i])
            {
                flag = 1;
                tq[j] = count;
                printf("page hit\n");
                break;
            }
        }
        
        // Page fault handles replacement
        if(flag == 0)
        {
            pf++;
            victim = find();
            frm[victim] = ref[i];
            tq[victim] = count;
        }
        
        // Display current frame status
        for(j = 0; j < nof; j++)
        {
            if(frm[j] != -1)
                printf("%d\t", frm[j]);
            else
                printf("-\t");
        }
    }
    
    printf("\n\nTotal number of page faults = %d\n", pf);
    return 0;
}

// Function to find the LRU page (victim frame)
int find()
{
    int i, minimum = tq[0], indexOfMinimum = 0;
    
    for(i = 1; i < nof; i++)
    {
        if(tq[i] < minimum)
        {
            minimum = tq[i];
            indexOfMinimum = i;
        }
    }
    return indexOfMinimum;
}