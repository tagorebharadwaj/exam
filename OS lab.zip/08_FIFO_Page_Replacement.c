﻿#include <stdio.h>

int main()
{
    int pages[30], frames[10];
    int n, f, i, j, k = 0;
    int fault = 0, found;

    printf("Enter number of pages: ");
    scanf("%d", &n);

    printf("Enter page reference string:\n");
    for(i = 0; i < n; i++)
        scanf("%d", &pages[i]);

    printf("Enter number of frames: ");
    scanf("%d", &f);

    if(f <= 0 || f > 10 || n <= 0 || n > 30)
    {
        printf("Invalid number of frames or pages.\n");
        return 1;
    }

    for(i = 0; i < f; i++)
        frames[i] = -1;

    for(i = 0; i < n; i++)
    {
        found = 0;

        for(j = 0; j < f; j++)
        {
            if(frames[j] == pages[i])
            {
                found = 1;
                break;
            }
        }

        if(found == 0)
        {
            frames[k] = pages[i];
            k = (k + 1) % f;
            fault++;
        }

        printf("\n");
        for(j = 0; j < f; j++)
        {
            if(frames[j] == -1)
                printf("- ");
            else
                printf("%d ", frames[j]);
        }
    }

    printf("\n\nTotal Page Faults = %d\n", fault);
    return 0;
}
/*
Input:
8
1 2 3 1 4 5 2 1
3

Output:
Total Page Faults = 7
*/
