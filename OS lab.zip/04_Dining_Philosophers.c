﻿#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t chopstick[5];

void *philosopher(void *arg)
{
    int id = *(int *)arg;
    int left = id;
    int right = (id + 1) % 5;

    printf("Philosopher %d is thinking\n", id + 1);

    
    if(id % 2 == 0)
    {
        pthread_mutex_lock(&chopstick[right]);
        pthread_mutex_lock(&chopstick[left]);
    }
    else
    {
        pthread_mutex_lock(&chopstick[left]);
        pthread_mutex_lock(&chopstick[right]);
    }

    printf("Philosopher %d is eating\n", id + 1);
    sleep(1);

    pthread_mutex_unlock(&chopstick[left]);
    pthread_mutex_unlock(&chopstick[right]);

    printf("Philosopher %d finished eating\n", id + 1);
    return NULL;
}

int main()
{
    pthread_t t[5];
    int id[5], i;

    for(i = 0; i < 5; i++)
        pthread_mutex_init(&chopstick[i], NULL);

    for(i = 0; i < 5; i++)
    {
        id[i] = i;
        pthread_create(&t[i], NULL, philosopher, &id[i]);
    }

    for(i = 0; i < 5; i++)
        pthread_join(t[i], NULL);

    for(i = 0; i < 5; i++)
        pthread_mutex_destroy(&chopstick[i]);

    return 0;
}
/*
Input:
No input required.

Output:
Philosopher 1 is thinking
Philosopher 1 is eating
Philosopher 1 finished eating
The order may vary.
*/

/*
Compile on Linux or WSL:
gcc 04_Dining_Philosophers.c -o dining -pthread
./dining

Viva Questions:
1. What problem does this program demonstrate?
   It demonstrates synchronization and deadlock prevention.
2. What is a mutex?
   A mutex is a lock that allows only one thread to access a resource at a time.
3. Why are the philosophers given different lock orders?
   Different lock orders prevent circular wait and avoid deadlock.
*/
