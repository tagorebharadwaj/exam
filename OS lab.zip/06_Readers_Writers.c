﻿#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t mutex, wrt;
int readcount = 0;
int data = 10;

void *reader(void *arg)
{
    int id = *(int *)arg;

    sem_wait(&mutex);
    readcount++;

    if(readcount == 1)
        sem_wait(&wrt);

    sem_post(&mutex);

    printf("Reader %d reads data = %d\n", id, data);
    sleep(1);

    sem_wait(&mutex);
    readcount--;

    if(readcount == 0)
        sem_post(&wrt);

    sem_post(&mutex);

    return NULL;
}

void *writer(void *arg)
{
    int id = *(int *)arg;

    sem_wait(&wrt);
    data++;
    printf("Writer %d writes data = %d\n", id, data);
    sleep(1);
    sem_post(&wrt);

    return NULL;
}

int main()
{
    pthread_t r[3], w;
    int id[3], wid = 1, i;

    sem_init(&mutex, 0, 1);
    sem_init(&wrt, 0, 1);

    for(i = 0; i < 3; i++)
    {
        id[i] = i + 1;
        pthread_create(&r[i], NULL, reader, &id[i]);
    }

    pthread_create(&w, NULL, writer, &wid);

    for(i = 0; i < 3; i++)
        pthread_join(r[i], NULL);

    pthread_join(w, NULL);

    sem_destroy(&mutex);
    sem_destroy(&wrt);

    return 0;
}
/*
Input:
No input required.

Output:
Reader 1 reads data = 10
Reader 2 reads data = 10
Reader 3 reads data = 10
Writer 1 writes data = 11
The order may vary.
*/

/*
Compile on Linux or WSL:
gcc 06_Readers_Writers.c -o readers_writers -pthread
./readers_writers

Viva Questions:
1. What problem does this program demonstrate?
   It demonstrates synchronization between readers and writers.
2. Can multiple readers access data at the same time?
   Yes, multiple readers can read concurrently.
3. Why must the writer get exclusive access?
   Exclusive access prevents readers from seeing partially updated data.
*/
