#include<stdio.h>
#include<semaphore.h>
#include<pthread.h>
#include<unistd.h>

sem_t chopstick[5];
pthread_t philos[5];

void *f1(void *p)
{
    int k=*(int *)p;
    printf("Philosopher-%d thinking\n",k);
    sleep(5);
    sem_wait(&chopstick[k]);
    sem_wait(&chopstick[(k+1)%5]);
    printf("Philosopher-%d eating\n",k);
    sleep(5);
    sem_post(&chopstick[k]);
    sem_post(&chopstick[(k+1)%5]);
    printf("Philosopher-%d finished eating\n",k);
}

int main()
{
    int i;
    for(i=0;i<5;i++)
        sem_init(&chopstick[i],0,1);
    for(i=0;i<5;i++)
    {
        pthread_create(&philos[i],NULL,f1,&i);
        sleep(1);
    }
    for(i=0;i<5;i++)
        pthread_join(philos[i],NULL);
    return 0;
}