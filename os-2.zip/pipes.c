#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
    pid_t pid;
    int pip[2];
    char s[20];

    pipe(pip);

    pid = fork();

    if (pid > 0)
    {
        close(pip[0]);  // Close read end

        printf("Parent running....\n");
        write(pip[1], "Hello world", 12);
        printf("Data written to pipe\n");

        close(pip[1]);

        wait(NULL);
        printf("Parent completed....\n");
    }
    else if (pid == 0)
    {
        close(pip[1]);  // Close write end

        printf("Child running....\n");
        read(pip[0], s, sizeof(s));
        printf("Data from pipe = %s\n", s);

        close(pip[0]);

        printf("Child completed....\n");
    }
    else
    {
        printf("Fork failed!\n");
    }

    return 0;
}