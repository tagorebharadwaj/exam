#include <stdio.h>
#include<unistd.h>
#include<semaphore.h>
#include<pthread.h>

int item,n=5;
sem_t mutex,empty,full;

void *producer()
{
    while(1)
    {
        sem_wait(&empty);
        sem_wait(&mutex);
        item++;
        sleep(2);
        printf("Producer produced item:%d\n",item);
        sem_post(&mutex);
        sem_post(&full);
    }
}

void *consumer()
{
    while(1)
    {
        sem_wait(&full);
        sem_wait(&mutex);
        sleep(2);
        printf("Consumer consumed item:%d\n",item--);
        sem_post(&mutex);
        sem_post(&empty);
    }
}

int main()
{
    pthread_t p,c;
    sem_init(&mutex,0,1);
    sem_init(&full,0,0);
    sem_init(&empty,0,n);
    pthread_create(&p,NULL,producer,NULL);
    pthread_create(&c,NULL,consumer,NULL);
    pthread_join(p,NULL);
    pthread_join(c,NULL);
    return 0;
}