#include <stdio.h>
#include<unistd.h>
#include<semaphore.h>
#include<pthread.h>

int item,rcount;
sem_t mutex,rwmutex;

void *writer(void *i)
{
    int k=*(int*)i;
    while(1)
    {
        sleep(2);
        sem_wait(&rwmutex);
        item++;
        printf("Writer-%d updated item:%d\n",k,item);
        sleep(2);
        sem_post(&rwmutex);
    }
}

void *reader(void *i)
{
    int k=*(int*)i;
    while(1)
    {
        sleep(5);
        sem_wait(&mutex);
        rcount++;
        if(rcount==1)
            sem_wait(&rwmutex);
        printf("Reader-%d reads item:%d\n",k,item);
        sleep(5);
        sem_post(&mutex);
        sem_wait(&mutex);
        rcount--;
        if(rcount==0)
            sem_post(&rwmutex);
        sem_post(&mutex);
    }
}

int main()
{
    pthread_t r[10],w[5];
    int i;
    sem_init(&mutex,0,1);
    sem_init(&rwmutex,0,100);
    for(i=0;i<5;i++)
    {
        pthread_create(&w[i],NULL,writer,&i);
    }
    for(i=0;i<10;i++){
        pthread_create(&r[i],NULL,reader,&i);
    }
    for(i=0;i<5;i++)
    {
        pthread_join(w[i],NULL);
    }
    for(i=0;i<10;i++){
        pthread_join(r[i],NULL);
    }
    return 0;
}