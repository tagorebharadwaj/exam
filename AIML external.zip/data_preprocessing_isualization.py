import pandas as pd
import matplotlib.pyplot as plt
# Load dataset (online CSV)
url = "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/iris.csv"
data = pd.read_csv(url)

# -------------------------------
# BASIC DATA UNDERSTANDING
# -------------------------------

print("First 5 rows:\n")
print(data.head())

print("\nLast 5 rows:\n")
print(data.tail())

print("\nColumns:\n")
print(data.columns)

print("\nShape of dataset:\n")
print(data.shape)

print("\nData types:\n")
print(data.dtypes)

print("\nBasic statistics:\n")
print(data.describe())

# -------------------------------
# DATA PREPROCESSING
# -------------------------------

# Check missing values
print("\nMissing values:\n")
print(data.isnull().sum())

# (Optional) Drop missing values
data = data.dropna()

# -------------------------------
# VISUALIZATION
# -------------------------------

# Scatter plot
plt.scatter(data["sepal_length"], data["sepal_width"])
plt.xlabel("Sepal Length")
plt.ylabel("Sepal Width")
plt.title("Sepal Length vs Width")
plt.show()