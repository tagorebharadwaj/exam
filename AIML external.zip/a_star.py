import heapq 
def a_star(graph, costs, start, goal, heuristic): 
    
    priority_queue = [(0 + heuristic[start], 0, start, [start])] 
    heapq.heapify(priority_queue) 
 
    
    g_costs = {start: 0} 
 
    while priority_queue: 
         
        f, current_g, current, path = heapq.heappop(priority_queue) 
  
        if current == goal: 
            print("Goal found!") 
            print(f"Path: {' -> '.join(path)} with cost: {current_g}") 
            return path, current_g 
 
        for neighbor in graph[current]: 
            tentative_g = current_g + costs[(current, neighbor)]

            if neighbor not in g_costs or tentative_g < g_costs[neighbor]: 
                g_costs[neighbor] = tentative_g 
                f_cost = tentative_g + heuristic[neighbor] 
                heapq.heappush(priority_queue, (f_cost, tentative_g, neighbor, path + [neighbor])) 
 
    print("Goal not found!") 
    return None, float('inf') 
  
graph = { 
    'S': ['A', 'B', 'G'], 
    'A': ['C','D'], 
    'B': ['D','E'], 
    'C': ['G'], 
    'D': ['G'], 
    'E': [], 
    'G': [] 
} 
  
costs = { 
    ('S', 'A'): 2, 
    ('S', 'B'): 1, 
    ('S', 'G'): 9, 
    ('A', 'C'): 2, 
    ('A', 'D'): 3, 
    ('B','D'):2, 
    ('B','E'):4, 
    ('C','G'):4, 
    ('D','G'):4 
} 
  
heuristic = { 
    'S':6, 
    'A': 5, 
    'B': 6, 
    'C': 4, 
    'D': 1, 
'E': 10, 
'G': 0  
} 
a_star(graph, costs, 'S', 'G', heuristic) 