# Create a Simulator object
set ns [new Simulator]

# Define colors for data flows
$ns color 1 Blue
$ns color 2 Red

# Open NAM trace file
set nf [open out.nam w]
$ns namtrace-all $nf

# Finish procedure
proc finish {} {
    global ns nf

    $ns flush-trace
    close $nf

    exec nam out.nam &
    exit 0
}

# Create nodes
set n0 [$ns node]
set n1 [$ns node]
set n2 [$ns node]
set n3 [$ns node]

# Create duplex links
$ns duplex-link $n0 $n2 2Mb 10ms DropTail
$ns duplex-link $n1 $n2 2Mb 10ms DropTail
$ns duplex-link $n2 $n3 1.7Mb 20ms DropTail

# Set queue limit
$ns queue-limit $n2 $n3 10

# Node orientation for NAM
$ns duplex-link-op $n0 $n2 orient right-down
$ns duplex-link-op $n1 $n2 orient right-up
$ns duplex-link-op $n2 $n3 orient right

# Queue position
$ns duplex-link-op $n2 $n3 queuePos 0.5

# TCP Agent
set tcp [new Agent/TCP]
$tcp set class_ 2
$ns attach-agent $n0 $tcp

# TCP Sink
set sink [new Agent/TCPSink]
$ns attach-agent $n3 $sink

# Connect TCP and Sink
$ns connect $tcp $sink
$tcp set fid_ 1

# FTP Application
set ftp [new Application/FTP]
$ftp attach-agent $tcp

# UDP Agent
set udp [new Agent/UDP]
$ns attach-agent $n1 $udp

# Null Agent
set null [new Agent/Null]
$ns attach-agent $n3 $null

# Connect UDP and Null
$ns connect $udp $null
$udp set fid_ 2

# CBR Application
set cbr [new Application/Traffic/CBR]
$cbr attach-agent $udp
$cbr set packetSize_ 1000
$cbr set rate_ 1Mb
$cbr set random_ false

# Schedule Events
$ns at 0.1 "$cbr start"
$ns at 1.0 "$ftp start"
$ns at 4.0 "$ftp stop"
$ns at 4.5 "$cbr stop"

# Optional detach
$ns at 4.5 "$ns detach-agent $n0 $tcp"
$ns at 4.5 "$ns detach-agent $n3 $sink"

# End simulation
$ns at 5.0 "finish"

# Display CBR parameters
puts "CBR packet size = [$cbr set packetSize_]"
puts "CBR rate = [$cbr set rate_]"

# Run simulation
$ns run