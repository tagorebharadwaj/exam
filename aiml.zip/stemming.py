import nltk
from nltk.stem import PorterStemmer, WordNetLemmatizer

# Download required NLTK data
nltk.download('wordnet')
nltk.download('omw-1.4')

# Stemming
porter = PorterStemmer()

stemmed_words = [porter.stem(word) for word in filtered_words]

stemmed_paragraph = ' '.join(stemmed_words)

print("Stemmed Paragraph:")
print(stemmed_paragraph)

# Lemmatization
lemmatizer = WordNetLemmatizer()

lemmatized_words = [lemmatizer.lemmatize(word) for word in filtered_words]

lemmatized_paragraph = ' '.join(lemmatized_words)

print("\nLemmatized Paragraph:")
print(lemmatized_paragraph)