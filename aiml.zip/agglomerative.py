# Initial Clusters
clusters = [[18], [22], [25], [27], [42], [43]]

# Distance Matrix
dist = [
    [0, 4, 7, 9, 24, 25],
    [4, 0, 3, 5, 20, 21],
    [7, 3, 0, 2, 17, 18],
    [9, 5, 2, 0, 15, 16],
    [24, 20, 17, 15, 0, 1],
    [25, 21, 18, 16, 1, 0]
]

while len(clusters) > 1:

    min_dist = float('inf')
    r = c = -1

    # Find minimum distance
    for i in range(len(dist)):
        for j in range(i + 1, len(dist)):
            if dist[i][j] < min_dist:
                min_dist = dist[i][j]
                r = i
                c = j

    print("\nMinimum Distance =", min_dist)
    print("Merging", clusters[r], "and", clusters[c])

    # Merge clusters
    new_cluster = clusters[r] + clusters[c]

    # Compute new distances using Single Linkage
    new_row = []
    for k in range(len(dist)):
        if k != r and k != c:
            d = min(dist[r][k], dist[c][k])
            new_row.append(d)

    # Remove merged clusters
    del clusters[c]
    del clusters[r]

    # Add new cluster
    clusters.append(new_cluster)

    # Create new distance matrix
    indices = [i for i in range(len(dist)) if i != r and i != c]

    new_dist = []
    for i in indices:
        row = []
        for j in indices:
            row.append(dist[i][j])
        new_dist.append(row)

    # Add distances for new cluster
    for i in range(len(new_dist)):
        new_dist[i].append(new_row[i])

    new_row.append(0)
    new_dist.append(new_row)

    dist = new_dist

    print("Clusters:", clusters)

print("\nFinal Cluster:", clusters[0])