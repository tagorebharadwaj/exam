from nltk import pos_tag
nltk.download('averaged_perceptron_tagger')
# Perform POS tagging on the lemmatized words
pos_tags = pos_tag(lemmatized_words)
# Print the POS tags
print(pos_tags)