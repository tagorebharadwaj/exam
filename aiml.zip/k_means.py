import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# Define the data points
data_points = np.array([2, 4, 10, 12, 3, 20, 30, 11, 25]).reshape(-1, 1)

# Define the initial centroids
initial_centroids = np.array([4, 11]).reshape(-1, 1)

# Number of clusters
n_clusters = 2

# Initialize and fit the KMeans model
kmeans = KMeans(
    n_clusters=n_clusters,
    init=initial_centroids,
    n_init=1,
    random_state=42
)

kmeans.fit(data_points)

# Predict the cluster for each data point
cluster_labels = kmeans.predict(data_points)

# Print the results
print("Cluster Labels:", cluster_labels)
print("Final Centroids:", kmeans.cluster_centers_)

# Assign each data point to the nearest cluster
clusters = {i: [] for i in range(n_clusters)}

for point, label in zip(data_points.flatten(), cluster_labels):
    clusters[label].append(point)

# Print the clusters
for cluster_id, points in clusters.items():
    print(f"Cluster {cluster_id + 1}: {points}")

# Visualize the results
plt.figure(figsize=(8, 6))

colors = ['red', 'green']

for i in range(n_clusters):
    plt.scatter(
        data_points[cluster_labels == i],
        np.zeros_like(data_points[cluster_labels == i]),
        c=colors[i],
        label=f'Cluster {i + 1}'
    )

# Plot centroids
plt.scatter(
    kmeans.cluster_centers_,
    np.zeros_like(kmeans.cluster_centers_),
    c='yellow',
    marker='X',
    s=200,
    edgecolors='black',
    label='Centroids'
)

plt.xlabel('Data Points')
plt.title('K-Means Clustering')
plt.legend()
plt.grid(True)
plt.show()