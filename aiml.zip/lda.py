import pandas as pd
import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

# Load the Iris dataset
iris = load_iris()

# Create DataFrame
iris_df = pd.DataFrame(data=iris.data, columns=iris.feature_names)
iris_df['species'] = iris.target

# Save to CSV
iris_df.to_csv('iris.csv', index=False)

# Display initial DataFrame
print("Initial DataFrame:")
print(iris_df.head())

# Load data from CSV
data = pd.read_csv('iris.csv')

# Separate features and target
X = data.iloc[:, :-1].values
y = data['species'].values

# Display features and target
print("\nFeatures (X):")
print(pd.DataFrame(X, columns=iris.feature_names).head())

print("\nTarget (y):")
print(pd.DataFrame(y, columns=['species']).head())

# Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

# Standardize features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Display standardized features
print("\nStandardized Training Features (X_train):")
print(pd.DataFrame(X_train, columns=iris.feature_names).head())

print("\nStandardized Testing Features (X_test):")
print(pd.DataFrame(X_test, columns=iris.feature_names).head())

# Apply LDA
lda = LinearDiscriminantAnalysis(n_components=2)

X_train_lda = lda.fit_transform(X_train, y_train)
X_test_lda = lda.transform(X_test)

# Display transformed features
print("\nLDA Transformed Training Features (X_train_lda):")
print(pd.DataFrame(X_train_lda, columns=['LDA1', 'LDA2']).head())

print("\nLDA Transformed Testing Features (X_test_lda):")
print(pd.DataFrame(X_test_lda, columns=['LDA1', 'LDA2']).head())

# Visualize LDA components
plt.figure(figsize=(8, 6))

for i, target_name in enumerate(iris.target_names):
    plt.scatter(
        X_train_lda[y_train == i, 0],
        X_train_lda[y_train == i, 1],
        alpha=0.8,
        label=target_name
    )

plt.legend(loc='best')
plt.xlabel('LDA Component 1')
plt.ylabel('LDA Component 2')
plt.title('LDA of Iris Dataset')
plt.grid(True)
plt.show()