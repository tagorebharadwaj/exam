import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Download required NLTK data
nltk.download('stopwords')
nltk.download('punkt')

# Example paragraph
paragraph = """
Natural language processing (NLP) is a subfield of linguistics,
computer science, and artificial intelligence concerned with the
interactions between computers and human language, in particular
how to program computers to process and analyze large amounts of
natural language data.
"""

# Tokenize the paragraph into words
words = word_tokenize(paragraph)

# Get the list of English stop words
stop_words = set(stopwords.words('english'))

# Remove stop words
filtered_words = [
    word for word in words
    if word.lower() not in stop_words
]

# Join filtered words into a paragraph
filtered_paragraph = ' '.join(filtered_words)

# Print the result
print("Filtered Paragraph:")
print(filtered_paragraph)