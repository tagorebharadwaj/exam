import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier #Fixed the typo in the module name
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix # Fixed the typo in the module
name
import matplotlib.pyplot as plt
iris=load_iris()
x=iris.data
y=iris.target
x_train,x_test,y_train,y_test =train_test_split(x,y,test_size=0.2,random_state=42)
clf=KNeighborsClassifier(n_neighbors=3)
clf.fit(x_train,y_train)
y_pred=clf.predict(x_test)
accuracy=accuracy_score(y_test,y_pred)
report=classification_report(y_test,y_pred)
conf_matrix =confusion_matrix(y_test,y_pred)
print(f'Accuracy :{accuracy}')
print("Classification Report:")
print(report)
print("Confusion Matrix:")
print(conf_matrix)
plt.figure(figsize=(12,8))
plt.show()